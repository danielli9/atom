# C0 language support in Atom

Adds syntax highlighting and snippets to C0 files in Atom.

Contributions are greatly appreciated. Please fork this repository and open a
pull request to add snippets, make grammar tweaks, etc.
